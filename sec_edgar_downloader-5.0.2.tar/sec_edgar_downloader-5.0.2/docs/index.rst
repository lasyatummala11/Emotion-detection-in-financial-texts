.. toctree::
    :maxdepth: 2

.. include:: ../README.rst

API Guide
---------

Downloader
^^^^^^^^^^

.. automodule:: sec_edgar_downloader._Downloader
    :members:
